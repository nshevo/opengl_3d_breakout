#include "TestWindow.h"

int main() {
    TestWindow window(800, 600, "GLFont");
    window.run();
}